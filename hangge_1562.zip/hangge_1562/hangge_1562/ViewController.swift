//
//  ViewController.swift
//  hangge_1562
//
//  Created by hangge on 2018/9/28.
//  Copyright © 2018年 hangge. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var webUploader = GCDWebUploader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        start();
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func start() {
        //let documentsPath: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).map(\.path).first
        //let documentsPath: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first as URL!
        //webUploader = GCDWebUploader(uploadDirectory: documentsPath!)
        let documentsPath = NSHomeDirectory() + "/Documents"
        webUploader = GCDWebUploader(uploadDirectory: documentsPath)
        // 设置代理
        //webUploader.delegate = self;
        //webUploader.allowHiddenItems = YES;
        
        // 限制文件上传类型
        webUploader.allowedFileExtensions = ["mp3", "wav", "amr", "aac", "mp4", "avi", "mpg","mov","wmv","flv", "rmvb", "xls", "xlsx", "txt", "pdf"];
        // 设置网页标题
        webUploader.title = "WIFI传歌";
        // 设置展示在网页上的文字(开场白)
        webUploader.prologue = "WIFI传歌";
        // 设置展示在网页上的文字(收场白)
        webUploader.epilogue = "TDL";
        webUploader.start(withPort: 8080, bonjourName: "GCDWebUploader Server")
        if let serverURL = webUploader.serverURL {
            print("Server start success.Visit \(serverURL) in your web browser.")
        }
    }
    
    func startDAVServer() {
        //默认上传目录是App的用户文档目录
        let documentsPath = NSHomeDirectory() + "/Documents"
        let _webServer = GCDWebDAVServer(uploadDirectory: documentsPath)
        _webServer.start(withPort: 8080, bonjourName: "GCDWebDAVServer Server")
        print("服务启动成功，使用你的WebDAV客户端访问：\(_webServer.serverURL)")
    }
}
